animalsay 0.1.0

USAGE:
    animalsay [FLAGS] [OPTIONS] [message]

FLAGS:
    -h, --help       Prints help information
    -m, --moose      Enter the animal you want to see!
    -i, --stdin      Read msg from stdin
    -V, --version    Prints version information

OPTIONS:
    -f, --file <file>    Use other ascii animals by placing in a .txt file by default animal.txt has monke art

ARGS:
    <message>    Enter your msg here! [default: Moose say Moo!]